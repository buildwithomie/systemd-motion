#!/usr/bin/env python3

# Import the core functionality
from motion.core import main

if __name__ == "__main__":
    main()