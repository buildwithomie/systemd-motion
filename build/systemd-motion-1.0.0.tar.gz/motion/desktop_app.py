#!/usr/bin/env python3

import sys
import os
from motion.gui import main

if __name__ == "__main__":
    sys.exit(main())
